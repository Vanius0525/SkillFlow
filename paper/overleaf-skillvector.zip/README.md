# Overleaf review draft

Main file: main.tex. Compiler: pdfLaTeX. Bibliography: BibTeX.

Upload this ZIP directly as a new Overleaf project. The default
build is the WWW submission manuscript. This project contains
only the submission and its references and compact appendix.

The mechanism section includes measured Qwen3-8B/MedCalc results.

This project contains only TeX inputs, referenced PDF figures,
the bibliography and this README. No local absolute paths,
experiment scripts, raw logs or build caches are needed.
