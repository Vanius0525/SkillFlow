# Overleaf review draft

Main file: main.tex. Compiler: pdfLaTeX. Bibliography: BibTeX.

Upload this ZIP directly as a new Overleaf project. The default
build is the WWW submission manuscript. This project contains
only the submission and its references and compact appendix.

The mechanism section includes measured Qwen3-8B/MedCalc results.

Depth displays report six main comparisons across four model families, plus a supplementary Qwen3-0.6B scale check (seven verified comparisons total).
Additional controls and legacy TheoremQA replays remain under audit;
the current mechanism displays are restricted to Qwen3-8B/MedCalc.

This project contains only TeX inputs, referenced PDF figures,
the bibliography and this README. No local absolute paths,
experiment scripts, raw logs or build caches are needed.
